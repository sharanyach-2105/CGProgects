package com.covalant.automation.scripts;

public class TestOpencart  extends BaseTestCase  {

	public void testAppProduct(){
		
		
	}
}
