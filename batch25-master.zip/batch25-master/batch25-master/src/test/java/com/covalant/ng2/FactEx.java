package com.covalant.ng2;

import org.testng.annotations.Test;

public class FactEx {

	
	@Test
	public void test2(){
		System.out.println("I am test");
	}
	
	
}
