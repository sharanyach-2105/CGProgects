
package com.covalant.cal;

import org.testng.annotations.Test;

public class Operations {

	
	@Test
	public void test3(){
		SwithExample e  = new SwithExample();
	  e.test3(WeekDay.FRIDAY);
		
	}
}
