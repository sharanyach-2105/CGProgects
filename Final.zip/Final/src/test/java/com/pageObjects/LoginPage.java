package com.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	WebDriver ldriver;  //create driver object
	
	LoginPage(WebDriver rdriver)  //constructor with parameter
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);    //pagefactory class
	}
	
	//To identify the elements in the login page
	@FindBy(name="MyAccount")
	@CacheLookup
	WebElement btnMyAccount;
	
	@FindBy(name="email")
	@CacheLookup
	WebElement txtEmailAddress;
	
	@FindBy(name="password")
	@CacheLookup
	WebElement txtPassword;
	
	@FindBy(name="btnLogin")
	@CacheLookup
	WebElement btnLogin;
	
	
	
}
