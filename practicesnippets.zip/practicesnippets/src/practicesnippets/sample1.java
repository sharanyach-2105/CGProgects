package practicesnippets;

public class sample1 {
public static void main(String args[]){
	if(new Boolean("true")==new Boolean("true"))
		System.out.println("Hi");
	else {
		System.out.println("Hello");
	}

}
}
////output:  Hello


//package practicesnippets;
//
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//public class sample1 {
//public static void main(String... args){
//	Pattern p = Pattern.compile("a*b");
//	Matcher m = p.matcher("b");
//	boolean b=m.matches();
//	System.out.println(b);
//}
//} //output: true
//
//


////package practicesnippets;
////public class sample1 {
////	public static void main(String... args){
////	String a ="Welcome";
////	int b=20;
////	int c=7;
////			System.out.println(a+b+c);
////	}
////}
////
////q2
//package practicesnippets;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class sample1{
//	public static void main(String args[]){
//		List list = new ArrayList();
//		list.add("abc");
//		list.add(10);
//		list.add('a');
//		list.add(false);
//		list.remove('a');
//		System.out.println(list.size()); // error at this line 
//		
//	}}//output runtime error
//	
//	
//	
	//int[][] twoDimArray= {{1},{4},{7}}; //correct bcz two dimension ...3 array values 
	 //int[][] twoDimArray= {[1,2,3],{4,5,6},{7,8,9}};   //wrong because[]
	 //int[][] twoDimArray= {{1,2,3},{4,5,6},{7,8,9}};   //correct 
	//int[][] sampleArray = new int[5][]; //CORRECT
//public class sample1{
//	//int[][] sampleArray = new int[][5];   // wrong because Cannot specify an array dimension after an empty dimension
//}	
//	
//	
//}
//
//
//q3

//package practicesnippets;
//
//import java.util.Iterator;
//import java.util.TreeSet;
//
//public class sample1{
//	public static void main(String args[]) {
//		TreeSet ts= new TreeSet();
//		ts.add("FIVE");
//		ts.add("Four");
//		ts.add("THREE");
//		ts.add("ONE");
//		ts.add("Four");
//		System.out.println(ts.size());
//		
//		Iterator iterator =ts.iterator();
//		while(iterator.hasNext()) {
//			Object object=iterator.next();
//			System.out.print(object+"\t");
//		}
//		
//	}
//}//output: 4
          //FIVE	Four	ONE	   THREE	




//================================

//package practicesnippets;
//
//
//public class sample1{
//	public static void main(String args[])throws Exception {
//		try {
//			m1();
//			System.out.println("A");}finally {System.out.println("B");}
//		System.out.println("C");
//		}
//	public static void m1()throws Exception{
//		throw new Exception();
//
//}} 
////output: It will print B and Throws exception