package practicesnippets;

public class q2 {
	public static void main(String args[]){
		
	
	int n1 = 1;
	int n2 =8;
	do {
		n2--;
		++n1;
		
	}while(n1<5);
	System.out.println();
	
}

}
