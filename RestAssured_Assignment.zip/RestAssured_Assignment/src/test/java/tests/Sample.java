package tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Sample {
	public static void main(String[] args) {
		RestAssured.baseURI = "https://petstore.swagger.io/";
		//      https://petstore.swagger.io/v2/store/order          --> post request from store module
		//		https://petstore.swagger.io/v2/store/inventory      --> get  request from store module
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.get("/v2/store/inventory");
		System.out.println("Response Body is " + response.asString());
		System.out.println("Response Status is " + response.getStatusCode());

		
	}
}
