package tests;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.util.HashMap;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.response.Response;


public class TC_AccesstoPetstoreOrders {
	@Test(priority=1)
	public void test_getAll()
	{
		given()
		
		.when()
		.get("https://petstore.swagger.io/v2/store/inventory")
		.then()
		.statusCode(200);
	}
	@Test(priority=2)
	public void test_addNew() {
		HashMap data = new HashMap();
		data.put("id", "18");
		data.put("petId", " aerHuskyo");
		data.put("quantity", "5");
		data.put("shipDate","2022-08-17T12:45:59.947Z");
		data.put("status","placed");
		data.put("complete", "true");
		Response res = 
		given()
		.contentType("application/json")
		.body(data)
		.when()
		.post("https://petstore.swagger.io/v2/store/order")
		.then()
		.statusCode(200)
		.log().body()
		.extract().response();
		
		String jsonString = res.asString();
		Assert.assertEquals(jsonString.contains("successful operation"), true);
		
	}
	
	@Test(priority=3)
	public void test_getpet() {
		given()
		.when()
		.get("https://petstore.swagger.io/v2/store/order/18")
.then()
.statusCode(200)
.body("petId", equalTo("18"))
.body("quantity", equalTo("5"));
		
	}
}

