package tests;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;
import org.json.simple.JSONObject;

import static io.restassured.RestAssured.*;


public class Tests_POST {
	@Test
	public void test_1_post() {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
	//map.put("petId", "12345");
	//map.put("status", "available");
	
	//System.out.println(map);
	
	//to convert into json object 
	JSONObject request = new JSONObject();  //map 
	
	request.put("petId", "12345");
	request.put("status", "available");
	
	System.out.println(request);
	System.out.println(request.toJSONString());
//	
//	given().
//	body(request.toJSONString()).
//	when().
//	post("https://petstore.swagger.io/v2/store/order").
//	then().
//	statusCode(200);

}
}
