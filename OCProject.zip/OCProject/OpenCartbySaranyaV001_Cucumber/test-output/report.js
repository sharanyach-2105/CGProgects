$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/resources/Features/org.url.feature/login.feature");
formatter.feature({
  "name": "Login",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Successful Login with valid credentials",
  "description": "    Given: User Launch Chrome Browser",
  "keyword": "Scenario"
});
formatter.step({
  "name": "User Opens URL\"https://demo.opencart.com/\"",
  "keyword": "When "
});
formatter.match({
  "location": "com.StepDefinition.login.user_Opens_URL(java.lang.String)"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user click on My Account",
  "keyword": "Then "
});
formatter.match({
  "location": "com.StepDefinition.login.user_click_on_My_Account()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user Click on Login button",
  "keyword": "And "
});
formatter.match({
  "location": "com.StepDefinition.login.user_Click_on_Login_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "User enters Email Address \"sharanyach.2105@gmail.com\" and Password as \"saranya1234\"",
  "keyword": "And "
});
formatter.match({
  "location": "com.StepDefinition.login.user_enters_Email_Address_and_Password_as(java.lang.String,java.lang.String)"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "click on Login",
  "keyword": "And "
});
formatter.match({
  "location": "com.StepDefinition.login.click_on_Login()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "page title should be \"Your Store\"",
  "keyword": "Then "
});
formatter.match({
  "location": "com.StepDefinition.login.page_title_should_be(java.lang.String)"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "User click on Logout button",
  "keyword": "When "
});
formatter.match({
  "location": "com.StepDefinition.login.user_click_on_Logout_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Page Title should be \"Your store Account Logout\"",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.step({
  "name": "close browser",
  "keyword": "And "
});
formatter.match({
  "location": "com.StepDefinition.login.close_browser()"
});
formatter.result({
  "status": "skipped"
});
});