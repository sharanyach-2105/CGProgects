//package com.pageObjects;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.CacheLookup;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.PageFactory;
//
//public class LoginPage {
//
//	public WebDriver ldriver;
//
//	public LoginPage(WebDriver rdriver) {
//		ldriver = rdriver;
//		PageFactory.initElements(rdriver, this);
//	}
//
//	@FindBy(id = "Email Address")
//	@CacheLookup
//	WebElement txtEmailAddress;
//
//	@FindBy(id = "Password")
//	@CacheLookup
//	WebElement txtPassword;
//
//	@FindBy(xpath = "//input[@value='Log in']") // //*[@id="content"]/div/div[2]/div/form/input
//	@CacheLookup
//	WebElement btnLogin;
//
//	@FindBy(linkText = "Logout")
//	@CacheLookup
//	WebElement lnkLogout;
//
//	public void setUserName(String uname) {
//		txtEmailAddress.clear();
//		txtEmailAddress.sendKeys(uname);
//	}
//
//	public void setPassword(String pwd) {
//		txtPassword.clear();
//		txtPassword.sendKeys(pwd);
//	}
//
//	public void clickLogin() {
//		btnLogin.click();
//
//	}
//
//	public void clickLogout() {
//		lnkLogout.click();
//
//	}
//
//	public void clickMyAccount() {
//		
//	}
//
//}
