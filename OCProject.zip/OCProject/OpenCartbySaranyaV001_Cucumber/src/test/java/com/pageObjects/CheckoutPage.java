package com.pageObjects;

public class CheckoutPage {

}
