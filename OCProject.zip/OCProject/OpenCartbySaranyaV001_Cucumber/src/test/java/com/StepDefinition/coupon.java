package com.StepDefinition;

import org.browser.com.browser;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class coupon extends browser {
	
	@Given("user is on shopping cart Page")
	public void user_is_on_shopping_cart_Page() {
	    }

	@When("user can click on Use coupon code")
	public void user_can_click_on_Use_coupon_code()  {
	    }

	@Then("user can enter valid  {string}")
	public void user_can_enter_valid(String string) {
	    }

	@Then("user clicks on apply coupon")
	public void user_clicks_on_apply_coupon() {
	    }

	@Then("user can check coupon is applied")
	public void user_can_check_coupon_is_applied() {
	    }


}
