package com.StepDefinition;

import java.util.concurrent.TimeUnit;

import org.browser.com.browser;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class search extends browser {
	public WebElement search;

	@Given("user is on the search page {string}")
	public void user_is_on_the_search_page(String string) {
		browser.setDriver();
		browser.getURL(string);

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

// driver.get(string);
	}

	@When("user enter {string} data in search box")
	public void user_enter_data(String string) {
		try {
			browser.searchText(string);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@When("click on search button")
	public void click_on_search() throws InterruptedException {
		try {
			browser.clickMethod();
		} catch (Exception e) {
			e.printStackTrace();
		}
		Thread.sleep(3000);
	}

	@Then("user is navigated to the search page")
	public void user_is_navigated_to_the_search_page(String string) {

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		browser.closeBrowser();

	}
}
