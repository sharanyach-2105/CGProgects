//package com.StepDefinition;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.Assert;
//
//import com.pageObjects.LoginPage;
//
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//public class login {
//
//	
//	public WebDriver driver;
//	public LoginPage lp; //use across all the methods so global 
//	
//	@Given("User Launch Chrome browser")
//	public void user_Launch_Chrome_browser() {
//		System.setProperty("webdriver.chrome.driver", System.getProperty("user")+"//Drivers/chromedriver.exe");
//		driver=new ChromeDriver();
//		
//		lp=new LoginPage(driver);
//
//	}
//
//	@When("User Opens URL{string}")
//	public void user_Opens_URL(String url) {
//		driver.get(url);
//	}
//
//	@Then("user click on My Account")
//	public void user_click_on_My_Account() {
//		lp.clickMyAccount();
//		
//	}
//
//	@Then("user Click on Login button")
//	public void user_Click_on_Login_button() {
//	lp.clickLogin();	
//	}
//
//	@When("User enters Email Address {string} and Password as {string}")
//	public void user_enters_Email_Address_and_Password_as(String emailaddress, String password) {
//	lp.setUserName(emailaddress);
//	lp.setPassword(password);
//	
//	}
//
//	@When("click on Login")
//	public void click_on_Login() {
//		lp.clickLogin();
//	}
//
//	@Then("page title should be {string}")
//	public void page_title_should_be(String title) {
//	
//	if (driver.getPageSource().contains("Login was unsuccessful.")) {
//		driver.close();
//		Assert.assertTrue(false);
//	}else {
//		Assert.assertEquals(title,driver.getTitle());
//	}
//	}
//	@Then("Page Title should be {string}")
//	public void page_Title_should_be(String title) {
//		if (driver.getPageSource().contains("Login was unsuccessful.")) {
//			driver.close();
//			Assert.assertTrue(false);
//		}else {
//			Assert.assertEquals(title,driver.getTitle());
//		}
//		
//	    }
//
//
//	@When("User click on Logout button")
//	public void user_click_on_Logout_button() throws InterruptedException {
//		lp.clickLogout();
//		Thread.sleep(3000);
//	}
//
//	
//	@Then("close browser")
//	public void close_browser() {
//		driver.close();
//		//driver.quit();
//	}
//
//}
