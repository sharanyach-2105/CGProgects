package com.StepDefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class estimateshipping {
	
	@When("user click on estimate shipping taxes")
	public void user_click_on_estimate_shipping_taxes() {
	    	}

	@Then("user enter valid  {string}")
	public void user_enter_valid(String string) {
	    	}

	@Then("user click on get quotes")
	public void user_click_on_get_quotes() {
	    }

	@Then("user is navigated to flatrate")
	public void user_is_navigated_to_flatrate() {
	    }

	@Then("click on flat shipping")
	public void click_on_flat_shipping() {
	    }

	@Then("click on Apply Shipping")
	public void click_on_Apply_Shipping() {
	    }

	@Then("user is navigated to shippingcart page")
	public void user_is_navigated_to_shippingcart_page() {
	    }




}
