package com.StepDefinition;

import org.browser.com.browser;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class addtocart extends browser {
	@Given("user open {string}")
	public void user_open(String string) {
		browser.setDriver();
		browser.getURL(string);
	}

	@When("user search for {string}")
	public void user_search_for(String string) {
		driver.findElement(By.xpath("//*[@id=\"small-searchterms\"]")).sendKeys("Health Book");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[3]/form/input[2]")).click();
	}

	@When("user open the Health Book")
	public void user_open_the_Health_Book() throws InterruptedException {
//WebElement PAGE_DOWN = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[3]/div[1]/div/div/div[2]/h2/a\""));
//Actions at = new Actions(driver);
//at.sendKeys(Keys.PAGE_DOWN).build().perform();
//driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[3]/div[1]/div/div/div[2]/h2/a")).click();
		Actions act = new Actions(driver);
		act.moveToElement(driver.findElement(
				By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[3]/div[1]/div/div/div[2]/h2/a")))
				.build().perform();
// driver.findElement(By.xpath("//*[@id=\\\"add-to-wishlist-button-22\\\"]")).click();
		driver.findElement(
				By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[3]/div[1]/div/div/div[2]/h2/a"))
				.click();
	}

	@When("user should able to click on add to whishlist button")
	public void user_should_able_to_click_on_add_to_whishlist_button() {
		driver.findElement(By.xpath("//*[@id=\"add-to-wishlist-button-22\"]")).click();
	}

	@When("user open my whishlist list")
	public void user_open_my_whishlist_list() {
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[4]/a/span[1]")).click();
	}

	@Then("user should see the Health Book in whishlist link")
	public void user_should_see_the_Health_Book_in_whishlist_link() {
		try {
			boolean result = browser.getTitle().matches("Whishlist link");
			Assert.assertEquals(true, result);
		} catch (Exception e) {
			System.out.println("No Such Products found whishlist link");
		}
		browser.closeBrowser();
	}
}
