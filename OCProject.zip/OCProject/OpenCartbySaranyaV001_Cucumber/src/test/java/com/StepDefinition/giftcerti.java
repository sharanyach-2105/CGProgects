package com.StepDefinition;

import java.util.concurrent.TimeUnit;

import org.browser.com.browser;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class giftcerti extends browser{
	
	public WebElement search;


	@When("user click on use gift certificate")
	public void user_click_on_use_gift_certificate(String string) {
		browser.setDriver();
		browser.getURL(string);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// driver.get(string);
	}

		
	

	@When("user enter valid {string}")
	public void user_enter_valid(String string) {
	}

	@Then("user click on apply gift certificate")
	public void user_click_on_apply_gift_certificate() {
	}

}
