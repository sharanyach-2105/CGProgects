
package com.StepDefinition;

import org.testng.Assert;

import java.util.concurrent.TimeUnit;

import org.browser.com.*;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class url extends browser {
	@Given("open the browser")
	public void open_the_browser() {
		browser.setDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	@When("enter the {string}")
	public void enter_the(String string) {
		browser.getURL(string);
	}

	@Then("page is displayed")
	public void page_is_displayed() {
		try {
			Thread.sleep(3000);
			Assert.assertEquals(browser.getTitle(), "Your Store");
		} catch (Exception e) {
			System.out.println("Title not found");
		}
		browser.closeBrowser();
	}
}
