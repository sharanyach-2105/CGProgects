package com.cg.practice;

public class question2 {
	int number = 30;
	void add() {
		number+=5;
		System.out.println(number);
	}
	public static void main(String[] args) {
		question2 q2=new question2();
		q2.add();
	}

}

/*
 * output 35 
 * explanation : number is instance variable
 *               so it can be modified.
 */