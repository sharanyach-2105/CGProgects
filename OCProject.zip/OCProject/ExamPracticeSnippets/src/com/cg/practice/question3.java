package com.cg.practice;

public class question3 {

	public static void main(String[] args) {
		int n1=1;
		int n2=8;
		do {
			n2--;
			++n1;
			
		}while(n1<5);
		System.out.println(n1+","+n2);
	}

}


/*output: 5,4 
 * expalnation: check the logic properly
 */
