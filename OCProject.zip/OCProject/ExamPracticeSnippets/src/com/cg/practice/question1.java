/**
 * 
 */
package com.cg.practice;

/**
 * @author sarcheek
 *
 */
public class question1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
	}

}
/*
 * abstract public class Account{ abstract void calculateInterestRate() { //code
 * for calculation interest rate } }
 */