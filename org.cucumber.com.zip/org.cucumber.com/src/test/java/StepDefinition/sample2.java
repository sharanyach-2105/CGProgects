package StepDefinition;

import org.browser.com.browser;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class sample2 extends browser{
	
	public WebElement search;
	@Given("user is on the search page {string}")
	public void user_is_on_the_search_page(String string) {
		browser.setDriver();
		browser.getURL(string);
	   // driver.get(string);
	}

	@When("user enters {string} data")
	public void user_enters_data(String string) {
		try {
			browser.searchText(string);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	    
	}

	@And("click on search")
	public void click_on_search() throws InterruptedException {
		try {
			browser.clickMethod();
		} catch (Exception e) {
			e.printStackTrace();
		}
		Thread.sleep(3000);
	    
	}

	@Then("user is navigated to the search page")
	public void user_is_navigated_to_the_search_page() {
		try
		{
		boolean result=browser.getTitle().matches("[A-Za-z]*[ ][-][ ]Google Search");
		Assert.assertEquals(true,result);
		}
		catch(Exception e)
		{
			System.out.println("User does not navigate to search page");
		}
		browser.closeBrowser();
	   
	}

}