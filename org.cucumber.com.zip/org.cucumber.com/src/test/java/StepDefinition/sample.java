package StepDefinition;

import org.browser.com.browser;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class sample extends browser{

	@Given("open the browser")
	public void open_the_browser() {
	  browser.setDriver();

	}

	@When("enter the {string}")
	public void enter_the(String string) {
		browser.getURL(string);
	   
	}

	@Then("Page is displayed")
	public void page_is_displayed() {
		try
		{
		Assert.assertEquals(browser.getTitle(),"Google");
		}
		catch(Exception e)
		{
			System.out.println("Title not found");
		}
		browser.closeBrowser();
	    
	}

}