package StepDefinition;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

/*
 * import io.cucumber.testng.CucumberOptions; import
 * io.cucumber.testng.AbstractTestNGCucumberTests;
 * 
 * @CucumberOptions(features="src\\test\\resources\\Features",
 * glue={"StepDefinition"},strict=true,monochrome=false, plugin=
 * {"pretty","html:target/htmlreports",
 * "json:target/jsonreports/jsonreports.json"}) //monochrome=false
 * 
 * public class TestRunner extends AbstractTestNGCucumberTests { //TestNG }
 */
@RunWith(Cucumber.class)
@CucumberOptions(features="src\\test\\resources\\Features",
 glue={"StepDefinition"},strict=true,monochrome=false, plugin=
 {"pretty","html:target/htmlreports",
 "json:target/jsonreports/jsonreports.json",
 "junit:target/junitreports/junitreports.xml"}) //monochrome=false
 
 public class TestRunner  { //JUnit 
	
}
